basic-node-bootstrap-webpage
============================

The barebones of a website using node.js, express, jade and bootstrap

This process of creating this code is recording in the blogpost at:
http://workingmatt.blogspot.co.uk/2014/04/build-nodejs-bootstrap-site-in-30.html

Building on node.js, express middleware was used to generate a bearbones web server/site.

Twitter's Bootstrap css style framework was added to this site.
Custom CSS was added to allow fixed height columns.

Some content was added to demonstrate responsive grid layout including fixed height columns.

This is a good starting point for building a website using node.js

Please follow @workingmatt, and checkout my blog at workingmatt.blogspot.co.uk

